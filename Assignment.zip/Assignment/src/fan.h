//// Khởi tạo quạt
//void fan_init();
//
//// Tắt quạt gió
//void fan_off(void);
//
//// Bật quạt gió
//void fan_on(void);
